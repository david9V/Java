package recurs;
import java.util.Scanner;
public class Anexo1 {

	static int recurs(int n,int i) {
		int k=2;
		if (k<n) {
			System.out.println(i+1);
			k++;
			return (recurs(n-1,i+1));
		} else return 0;
	}

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Introduzca un número para mostrar la secuencia numérica entre 1  dicho número: ");
		int n=sc.nextInt();
		int i=1;
		recurs(n,i);
	}

}