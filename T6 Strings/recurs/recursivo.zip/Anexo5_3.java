package recurs;

import java.util.Arrays;
import java.util.Scanner;

public class Anexo5_3 {

	static int busqBinRec(int tabla[],int n,int inf,int sup) {
		int centro=(inf+sup)/2;
		System.out.println("Centro "+centro);
		System.out.println(Arrays.toString(tabla));
		if (tabla[centro]==n) return centro;
		else if(inf>=sup) return -1;
		else if (tabla[centro]<n) return busqBinRec(tabla,n,centro+1,sup);
		else return busqBinRec(tabla,n,inf,centro-1);
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int indice;
		int tabla[]= {1,4,6,8,9,11,56,78,93,212};
		System.out.println("Introduzca un número a buscar: ");
		int n=sc.nextInt();
		indice=busqBinRec(tabla,n,0,tabla.length-1);
		System.out.println("Está en el índice: "+indice+" (-1 -> no encontrado)");
	}

}