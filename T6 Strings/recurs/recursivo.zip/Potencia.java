package recurs;
import java.util.Scanner;
public class Potencia {

	static double potenciaRec(int n,double num) {
		if (n==1) {
			return num;
		}
		else {
			return num*potenciaRec(n-1,num);
		}
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Introduzca un número real: ");
		double num=sc.nextDouble();
		System.out.println("Introduzca a cuanto quiere elevarlo: ");
		int n=sc.nextInt();
		double resultado=potenciaRec(n,num);
		System.out.println("La potencia de "+num+"^"+n+" es -> "+resultado);

	}

}
