package recurs;
import java.util.*;
public class Anexo6 {
	
	    static String alReves(String cadena){
	    	char reves;
	    	String alRevesv="";
	    	if (cadena.length()==1) {
	    		return cadena;
	    	} else {
	    		reves=cadena.charAt(cadena.length()-1);
	    		alRevesv=alRevesv+reves;
	    		return alRevesv+alReves(cadena.substring(0, cadena.length()-1)) ;
	    	}
	    	
	    }
	    
	    public static void main(String[] args) {
	        Scanner sc=new Scanner(System.in);
	        System.out.println("Escriba una palabra: ");
	        String cadena=sc.nextLine();
	        cadena=alReves(cadena);
	        System.out.println("Cadena al revés: " +cadena);
	    }
	}