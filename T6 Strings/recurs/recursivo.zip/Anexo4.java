package recurs;
import java.util.Scanner;
public class Anexo4 {

	static void binarioRec(int n) {
		if (n<2) {
			System.out.print(n);
			
		}
		else {
			binarioRec(n/2);
			System.out.print((n%2));
		}
	}
	
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Introduzca un numero para pasar a binario: ");
		int num=sc.nextInt();
		binarioRec(num);
		
	}

}
