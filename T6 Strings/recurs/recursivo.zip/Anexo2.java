package recurs;
import java.util.Scanner;

public class Anexo2 {
	
	static void recurs(int n) {
		if (n>2) {
			System.out.println(n-1);
			recurs(n-1);
		}
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Introduzca un número para mostrar la secuencia numérica entre 1  dicho número: ");
		int n=sc.nextInt();
		recurs(n);
	}

}