package recurs;
import java.util.*;
public class NumAlReves {

	static void numReves(int n) {
		if (n<10) {
			System.out.println(n);
		} else {
			System.out.print(n%10);
			numReves(n/10);
		}
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Escriba un número: ");
		int n=sc.nextInt();
		numReves(n);
	}

}
