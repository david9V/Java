package recurs;
import java.util.*;
public class Anexo3 {

	static int multiplicacionRecurs(int n1,int n2) {
		if (n2==0) {
			return 0;
		} else {
			return n1+multiplicacionRecurs(n1,n2-1);
		}
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Introduzca dos enteros para multiplicaros: ");
		int n1=sc.nextInt();
		int n2=sc.nextInt();
		int resultado=multiplicacionRecurs(n1,n2);
		System.out.println("La multiplicación de "+n1+" y "+n2+" es "+resultado);

	}

}
