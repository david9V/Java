package recurs;
import java.util.*;
public class factorial {

	static long recFacts(long n) {
		if (n==1) {
			return n;
		}
		else {
			return(n*recFacts(n-1));
		}
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		long resultado,n;
		System.out.println("Introduzca un número entero para calcular su factorial: ");
		n=sc.nextLong();
		resultado=recFacts(n);
		System.out.println("El factorial de "+n+" es -> "+resultado);

	}

}
