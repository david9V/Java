package recurs;

import java.util.Scanner;
import java.util.*;
public class MaximoVector {

	static int maximoRecursivo(int[] tabla,int i,int max) {
		if (i>tabla.length-1) {
			return max;
		} else if (tabla[i]>max) {
			max=tabla[i];
		}
		return maximoRecursivo(tabla,i+1,max);
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int tabla[]= {1,4,6,8,9,11,56,500,78,93,212,300};
		int i=0;
		int max=-1;
		max=maximoRecursivo(tabla,i,max);
		System.out.println("Máximo: "+max);
	}

}
