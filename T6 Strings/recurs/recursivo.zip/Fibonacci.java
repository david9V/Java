package recurs;
import java.util.Scanner;
public class Fibonacci {

	static int fibonacciRec(long n) {
		if (n==1) {
			return 1;
		} else if (n==0) {
			return 0;
		}
		else {
			return fibonacciRec(n-1)+fibonacciRec(n-2);
		}
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Introduzca la posición del número que quiere calcular de la sucesión de Fibonacci: ");
		long n=sc.nextInt();
		long resultado=fibonacciRec(n);
		System.out.println("Solución: "+resultado);
	}

}
